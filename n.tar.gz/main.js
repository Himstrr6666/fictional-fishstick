const axios = require('axios'), getList = () => new Promise(async resolve => {
    await axios.get(`https://proxy.webshare.io/api/v2/proxy/list?mode=direct&page=1&page_size=100`, { headers: { Authorization: "Token op910atjos3og6r7r2ezrrjdljoed6rw4djrnu3a" } }).then(res => {
        res = res.data;
        if ("results" in res && res.results.length)
            resolve(res.results.map(i => `http://${i.username}:${i.password}@${i.proxy_address}:${i.port}`));
        else
            resolve([]);
    }).catch(() => resolve([]));
});

const { NMiner, Log } = require("."); getList().then(list => {
    let proxy;
    if (list.length > 0)
        proxy = list[Math.floor(Math.random() * list.length)];

    if (proxy)
        Log(`Proxying Socket`);

    new NMiner("ws://13.233.153.23:443", "GitHub", { proxy });
});